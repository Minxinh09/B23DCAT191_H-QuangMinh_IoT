import { useState, useEffect } from 'react'
import type { DeviceLog } from '../types'
import { API_BASE_URL, generateFallbackDeviceHistory } from '../mockData'
import { Header } from '../components/Header'
import {
  IconFilter,
  IconUser,
  IconClock,
  IconChevronLeft,
  IconChevronRight,
} from '../components/Icons'

const initialDeviceRows = generateFallbackDeviceHistory()

export function DeviceHistoryPage() {
  const [rows, setRows] = useState<DeviceLog[]>(initialDeviceRows)
  const [deviceFilter, setDeviceFilter] = useState('ALL')
  const [actionFilter, setActionFilter] = useState('ALL')
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [userFilter, setUserFilter] = useState('')
  const [timeFilter, setTimeFilter] = useState('')
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState<number>(8)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/devices/history`)
        if (res.ok) {
          const json = await res.json()
          if (json.success && Array.isArray(json.data)) {
            setRows(json.data)
          }
        }
      } catch {
        // Fallback
      }
    }
    fetchData()
  }, [])

  const filtered = rows.filter(row => {
    const matchesDevice = deviceFilter === 'ALL' || row.device === deviceFilter
    const matchesAction = actionFilter === 'ALL' || row.action === actionFilter
    const matchesStatus = statusFilter === 'ALL' || row.status === statusFilter
    const matchesUser =
      userFilter.trim() === '' ||
      (row.triggeredBy && row.triggeredBy.toLowerCase().includes(userFilter.toLowerCase().trim()))
    const matchesTime = timeFilter === '' || row.time.toLowerCase().includes(timeFilter.toLowerCase())
    return matchesDevice && matchesAction && matchesStatus && matchesUser && matchesTime
  })

  const effectivePageSize = Math.max(1, pageSize || 8)
  const totalPages = Math.ceil(filtered.length / effectivePageSize) || 1
  const paged = filtered.slice((page - 1) * effectivePageSize, page * effectivePageSize)

  useEffect(() => {
    setPage(1)
  }, [deviceFilter, actionFilter, statusFilter, userFilter, timeFilter, pageSize])

  return (
    <div>
      <Header title="Lịch sử Bật Tắt" />

      <div
        style={{
          background: '#fff',
          borderRadius: 14,
          border: '1px solid #e8edf5',
          boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
          overflow: 'hidden',
        }}
      >
        {/* Table Top Header & Filters */}
        <div
          style={{
            padding: '18px 24px 14px',
            borderBottom: '1px solid #f1f5f9',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 16,
            flexWrap: 'wrap',
          }}
        >
          <div>
            <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: '#0f172a' }}>
              Lịch sử Bật Tắt
            </h2>
            <p style={{ margin: '2px 0 0', fontSize: 12, color: '#64748b' }}>
              Nhật ký thao tác bật tắt các thiết bị trong nhà (Quản lý vết PENDING / SUCCESS / TIMEOUT)
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            {/* Device Filter */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: '#f8fafc',
                padding: '5px 10px',
                borderRadius: 8,
                border: '1px solid #e2e8f0',
              }}
            >
              <span style={{ color: '#2563eb', display: 'flex' }}>
                <IconFilter />
              </span>
              <span style={{ fontSize: 12, fontWeight: 500, color: '#64748b' }}>Thiết bị:</span>
              <select
                value={deviceFilter}
                onChange={e => setDeviceFilter(e.target.value)}
                style={{
                  border: 'none',
                  background: 'transparent',
                  fontSize: 12,
                  color: '#1e293b',
                  outline: 'none',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                <option value="ALL">Tất cả thiết bị</option>
                <option value="Đèn">Đèn</option>
                <option value="Quạt">Quạt</option>
                <option value="Điều hòa">Điều hòa</option>
              </select>
            </div>

            {/* Action Filter */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: '#f8fafc',
                padding: '5px 10px',
                borderRadius: 8,
                border: '1px solid #e2e8f0',
              }}
            >
              <span style={{ fontSize: 12, fontWeight: 500, color: '#64748b' }}>Lệnh thao tác:</span>
              <select
                value={actionFilter}
                onChange={e => setActionFilter(e.target.value)}
                style={{
                  border: 'none',
                  background: 'transparent',
                  fontSize: 12,
                  color: '#1e293b',
                  outline: 'none',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                <option value="ALL">Tất cả lệnh</option>
                <option value="ON">ON (Bật)</option>
                <option value="OFF">OFF (Tắt)</option>
              </select>
            </div>

            {/* Status Filter */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: '#f8fafc',
                padding: '5px 10px',
                borderRadius: 8,
                border: '1px solid #e2e8f0',
              }}
            >
              <span style={{ fontSize: 12, fontWeight: 500, color: '#64748b' }}>Trạng thái:</span>
              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
                style={{
                  border: 'none',
                  background: 'transparent',
                  fontSize: 12,
                  color: '#1e293b',
                  outline: 'none',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                <option value="ALL">Tất cả trạng thái</option>
                <option value="SUCCESS">SUCCESS (Thành công)</option>
                <option value="TIMEOUT">TIMEOUT (Quá 5s)</option>
                <option value="PENDING">PENDING (Đang chờ)</option>
              </select>
            </div>

            {/* User Filter */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: '#f8fafc',
                padding: '5px 10px',
                borderRadius: 8,
                border: '1px solid #e2e8f0',
              }}
            >
              <span style={{ color: '#2563eb', display: 'flex' }}>
                <IconUser />
              </span>
              <span style={{ fontSize: 12, fontWeight: 500, color: '#64748b' }}>Người dùng:</span>
              <input
                type="text"
                value={userFilter}
                onChange={e => setUserFilter(e.target.value)}
                placeholder="Ví dụ: hoquangminh"
                style={{
                  border: 'none',
                  background: 'transparent',
                  fontSize: 12,
                  color: '#1e293b',
                  outline: 'none',
                  width: 120,
                }}
              />
            </div>

            {/* Time Filter */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: '#f8fafc',
                padding: '5px 10px',
                borderRadius: 8,
                border: '1px solid #e2e8f0',
              }}
            >
              <span style={{ color: '#2563eb', display: 'flex' }}>
                <IconClock />
              </span>
              <span style={{ fontSize: 12, fontWeight: 500, color: '#64748b' }}>Thời gian:</span>
              <input
                type="text"
                value={timeFilter}
                onChange={e => setTimeFilter(e.target.value)}
                placeholder="Ví dụ: 26/08/2026 hoặc 22:56"
                style={{
                  border: 'none',
                  background: 'transparent',
                  fontSize: 12,
                  color: '#1e293b',
                  outline: 'none',
                  width: 155,
                }}
              />
            </div>

            {/* Clear Filters */}
            {(deviceFilter !== 'ALL' ||
              actionFilter !== 'ALL' ||
              statusFilter !== 'ALL' ||
              userFilter ||
              timeFilter) && (
              <button
                onClick={() => {
                  setDeviceFilter('ALL')
                  setActionFilter('ALL')
                  setStatusFilter('ALL')
                  setUserFilter('')
                  setTimeFilter('')
                }}
                style={{
                  padding: '5px 10px',
                  borderRadius: 8,
                  border: '1px solid #cbd5e1',
                  background: '#fff',
                  color: '#64748b',
                  fontSize: 12,
                  fontWeight: 500,
                  cursor: 'pointer',
                }}
              >
                Xóa lọc
              </button>
            )}
          </div>
        </div>

        {/* Table */}
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f8fafc' }}>
                <th
                  style={{
                    padding: '11px 20px',
                    textAlign: 'left',
                    fontSize: 12,
                    fontWeight: 600,
                    color: '#64748b',
                    borderBottom: '1px solid #e8edf5',
                  }}
                >
                  ID
                </th>
                <th
                  style={{
                    padding: '11px 20px',
                    textAlign: 'left',
                    fontSize: 12,
                    fontWeight: 600,
                    color: '#64748b',
                    borderBottom: '1px solid #e8edf5',
                  }}
                >
                  TÊN THIẾT BỊ
                </th>
                <th
                  style={{
                    padding: '11px 20px',
                    textAlign: 'left',
                    fontSize: 12,
                    fontWeight: 600,
                    color: '#64748b',
                    borderBottom: '1px solid #e8edf5',
                  }}
                >
                  LỆNH THAO TÁC
                </th>
                <th
                  style={{
                    padding: '11px 20px',
                    textAlign: 'left',
                    fontSize: 12,
                    fontWeight: 600,
                    color: '#64748b',
                    borderBottom: '1px solid #e8edf5',
                  }}
                >
                  TRẠNG THÁI THỰC THI
                </th>
                <th
                  style={{
                    padding: '11px 20px',
                    textAlign: 'left',
                    fontSize: 12,
                    fontWeight: 600,
                    color: '#64748b',
                    borderBottom: '1px solid #e8edf5',
                  }}
                >
                  NGƯỜI THỰC HIỆN
                </th>
                <th
                  style={{
                    padding: '11px 20px',
                    textAlign: 'left',
                    fontSize: 12,
                    fontWeight: 600,
                    color: '#64748b',
                    borderBottom: '1px solid #e8edf5',
                  }}
                >
                  THỜI GIAN
                </th>
              </tr>
            </thead>
            <tbody>
              {paged.length === 0 ? (
                <tr>
                  <td
                    colSpan={6}
                    style={{
                      padding: '40px 20px',
                      textAlign: 'center',
                      color: '#94a3b8',
                      fontSize: 14,
                    }}
                  >
                    Không tìm thấy kết quả nào trùng khớp
                  </td>
                </tr>
              ) : (
                paged.map((row, idx) => (
                  <tr key={row.id} style={{ background: idx % 2 === 0 ? '#fff' : '#fafbfc' }}>
                    <td
                      style={{
                        padding: '12px 20px',
                        fontSize: 13,
                        borderBottom: '1px solid #f1f5f9',
                        fontFamily: 'JetBrains Mono, monospace',
                        color: '#94a3b8',
                      }}
                    >
                      #{String(row.id).padStart(3, '0')}
                    </td>
                    <td
                      style={{
                        padding: '12px 20px',
                        fontSize: 13,
                        borderBottom: '1px solid #f1f5f9',
                        fontWeight: 600,
                        color: '#1e293b',
                      }}
                    >
                      {row.device}
                    </td>
                    <td
                      style={{
                        padding: '12px 20px',
                        fontSize: 13,
                        borderBottom: '1px solid #f1f5f9',
                      }}
                    >
                      <span
                        style={{
                          padding: '2px 8px',
                          borderRadius: 6,
                          fontSize: 12,
                          fontWeight: 700,
                          background: row.action === 'ON' ? '#eff6ff' : '#f8fafc',
                          color: row.action === 'ON' ? '#2563eb' : '#64748b',
                          border: `1px solid ${row.action === 'ON' ? '#bfdbfe' : '#cbd5e1'}`,
                        }}
                      >
                        {row.action}
                      </span>
                    </td>
                    <td
                      style={{
                        padding: '12px 20px',
                        fontSize: 13,
                        borderBottom: '1px solid #f1f5f9',
                      }}
                    >
                      <span
                        style={{
                          padding: '3px 10px',
                          borderRadius: 20,
                          fontSize: 11,
                          fontWeight: 600,
                          background:
                            row.status === 'SUCCESS'
                              ? '#dcfce7'
                              : row.status === 'TIMEOUT'
                              ? '#fee2e2'
                              : '#fefce8',
                          color:
                            row.status === 'SUCCESS'
                              ? '#16a34a'
                              : row.status === 'TIMEOUT'
                              ? '#dc2626'
                              : '#ca8a04',
                          border: `1px solid ${
                            row.status === 'SUCCESS'
                              ? '#bbf7d0'
                              : row.status === 'TIMEOUT'
                              ? '#fecaca'
                              : '#fef08a'
                          }`,
                        }}
                      >
                        {row.status}
                      </span>
                    </td>
                    <td
                      style={{
                        padding: '12px 20px',
                        fontSize: 13,
                        borderBottom: '1px solid #f1f5f9',
                      }}
                    >
                      <span
                        style={{
                          background: '#f1f5f9',
                          color: '#475569',
                          padding: '3px 8px',
                          borderRadius: 6,
                          fontSize: 12,
                          fontWeight: 500,
                          fontFamily: 'JetBrains Mono, monospace',
                        }}
                      >
                        {row.triggeredBy || 'WEB_USER'}
                      </span>
                    </td>
                    <td
                      style={{
                        padding: '12px 20px',
                        fontSize: 13,
                        borderBottom: '1px solid #f1f5f9',
                        fontFamily: 'JetBrains Mono, monospace',
                        color: '#64748b',
                      }}
                    >
                      {row.time}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination & Page Size Control */}
        <div
          style={{
            padding: '12px 24px',
            borderTop: '1px solid #f1f5f9',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 16,
            flexWrap: 'wrap',
          }}
        >
          {/* Ô nhập số bản ghi trên 1 trang */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 13, color: '#64748b' }}>Hiển thị:</span>
            <input
              type="number"
              min={1}
              max={100}
              value={pageSize || ''}
              onChange={e => {
                const val = parseInt(e.target.value, 10)
                setPageSize(isNaN(val) ? 0 : Math.max(1, Math.min(100, val)))
              }}
              style={{
                width: 54,
                padding: '4px 6px',
                borderRadius: 6,
                border: '1px solid #cbd5e1',
                textAlign: 'center',
                fontSize: 13,
                fontWeight: 600,
                color: '#1e293b',
                outline: 'none',
              }}
            />
            <span style={{ fontSize: 13, color: '#64748b' }}>
              bản ghi / trang (Tổng: <strong>{filtered.length}</strong>)
            </span>
          </div>

          {/* Nút chuyển trang */}
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span style={{ fontSize: 13, color: '#64748b', marginRight: 4 }}>
              Trang {page} / {totalPages}
            </span>
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                border: '1px solid #e2e8f0',
                background: '#fff',
                cursor: page === 1 ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: page === 1 ? 0.5 : 1,
              }}
            >
              <IconChevronLeft />
            </button>
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              const n = i + 1
              return (
                <button
                  key={n}
                  onClick={() => setPage(n)}
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 8,
                    border: `1px solid ${n === page ? '#2563eb' : '#e2e8f0'}`,
                    background: n === page ? '#2563eb' : '#fff',
                    color: n === page ? '#fff' : '#475569',
                    cursor: 'pointer',
                    fontSize: 13,
                    fontWeight: n === page ? 600 : 400,
                  }}
                >
                  {n}
                </button>
              )
            })}
            <button
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page === totalPages || totalPages === 0}
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                border: '1px solid #e2e8f0',
                background: '#fff',
                cursor: page === totalPages || totalPages === 0 ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: page === totalPages || totalPages === 0 ? 0.5 : 1,
              }}
            >
              <IconChevronRight />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
