import { useState } from 'react'
import type { Page, User, ToastMessage } from './types'
import { Sidebar } from './components/Sidebar'
import { ToastContainer } from './components/Toast'
import { LoginScreen } from './pages/LoginScreen'
import { DashboardPage } from './pages/DashboardPage'
import { SensorHistoryPage } from './pages/SensorHistoryPage'
import { DeviceHistoryPage } from './pages/DeviceHistoryPage'
import { ProfilePage } from './pages/ProfilePage'

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('iot_current_user')
    return saved ? JSON.parse(saved) : null
  })

  const [page, setPage] = useState<Page>('dashboard')
  const [toasts, setToasts] = useState<ToastMessage[]>([])

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user)
    localStorage.setItem('iot_current_user', JSON.stringify(user))
  }

  const handleLogout = () => {
    setCurrentUser(null)
    localStorage.removeItem('iot_current_user')
  }

  const addToast = (text: string, type: 'success' | 'error') => {
    const id = Date.now()
    setToasts(prev => [...prev, { id, text, type }])
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id))
    }, 3500)
  }

  if (!currentUser) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />
  }

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#f0f2f5', fontFamily: 'Inter, sans-serif' }}>
      <ToastContainer toasts={toasts} />
      <Sidebar page={page} setPage={setPage} user={currentUser} onLogout={handleLogout} />
      <main style={{ flex: 1, padding: '20px 28px', overflowY: 'auto' }}>
        {page === 'dashboard' && <DashboardPage addToast={addToast} />}
        {page === 'sensor-history' && <SensorHistoryPage />}
        {page === 'device-history' && <DeviceHistoryPage />}
        {page === 'profile' && <ProfilePage />}
      </main>

      <style>{`
        @keyframes pulse-dot {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        @keyframes slide-in {
          from { transform: translateY(-20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .animate-spin {
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  )
}