import type { ToastMessage } from '../types'

export function ToastContainer({ toasts }: { toasts: ToastMessage[] }) {
  return (
    <div style={{ position: 'fixed', top: 24, right: 24, zIndex: 9999, display: 'flex', flexDirection: 'column', gap: 10 }}>
      {toasts.map(toast => (
        <div
          key={toast.id}
          style={{
            padding: '12px 18px',
            borderRadius: 10,
            fontSize: 13,
            fontWeight: 600,
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            boxShadow: '0 4px 12px rgba(0,0,0,0.12)',
            background: toast.type === 'success' ? '#10b981' : toast.type === 'error' ? '#ef4444' : '#3b82f6',
            color: '#fff',
            animation: 'slide-in 0.25s ease-out',
          }}
        >
          {toast.text}
        </div>
      ))}
    </div>
  )
}
