export type Page = 'dashboard' | 'sensor-history' | 'device-history' | 'profile'

export interface User {
  username: string
  fullName: string
  role: string
}

export interface SensorReading {
  id: number
  sensorName: string
  sensorType: 'TEMPERATURE' | 'HUMIDITY' | 'LIGHT'
  value: number
  unit: string
  time: string
}

export interface DeviceLog {
  id: number
  device: string
  action: 'ON' | 'OFF'
  status: 'SUCCESS' | 'PENDING' | 'TIMEOUT' | 'FAILED'
  triggeredBy: string
  time: string
}

export type DeviceStatusState = 'ON' | 'OFF' | 'PENDING'

export interface DeviceState {
  light: DeviceStatusState
  fan: DeviceStatusState
  ac: DeviceStatusState
}

export interface ChartPoint {
  t: string
  temp: number
  humidity: number
  light: number
}

export interface ToastMessage {
  id: number
  type: 'success' | 'error' | 'info'
  text: string
}
