export function Header({
  title,
  isConnected = true,
}: {
  title: string
  isConnected?: boolean
}) {
  const dateStr = new Date().toLocaleString('vi-VN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })

  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
      <div>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: '#0f172a' }}>{title}</h1>
        <p style={{ margin: '2px 0 0', fontSize: 13, color: '#64748b' }}>{dateStr}</p>
      </div>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 7,
          background: isConnected ? '#dcfce7' : '#fee2e2',
          color: isConnected ? '#16a34a' : '#dc2626',
          padding: '6px 14px',
          borderRadius: 20,
          fontSize: 13,
          fontWeight: 600,
          border: `1px solid ${isConnected ? '#bbf7d0' : '#fecaca'}`,
          transition: 'all 0.3s ease',
        }}
      >
        <span
          style={{
            width: 8,
            height: 8,
            borderRadius: '50%',
            background: isConnected ? '#16a34a' : '#dc2626',
            display: 'inline-block',
            animation: isConnected ? 'pulse-dot 2s infinite' : 'none',
          }}
        />
        {isConnected ? 'Mạch đã kết nối' : 'Mạch đã ngắt kết nối'}
      </div>
    </div>
  )
}

