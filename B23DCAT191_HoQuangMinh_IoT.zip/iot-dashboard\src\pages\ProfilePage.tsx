import { Header } from '../components/Header'
import { IconUser } from '../components/Icons'

export function ProfilePage() {
  return (
    <div>
      <Header title="Profile" />

      <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 20 }}>
        <div
          style={{
            width: '100%',
            maxWidth: 440,
            background: '#fff',
            borderRadius: 20,
            padding: '36px 32px',
            border: '1px solid #e8edf5',
            boxShadow: '0 10px 25px rgba(0,0,0,0.05)',
            textAlign: 'center',
          }}
        >
          {/* Avatar */}
          <div
            style={{
              width: 100,
              height: 100,
              borderRadius: '50%',
              margin: '0 auto 16px',
              background: 'linear-gradient(135deg, #1e293b, #0f172a)',
              border: '4px solid #3b82f6',
              color: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 6px 16px rgba(59,130,246,0.3)',
            }}
          >
            <IconUser size={38} />
          </div>

          <h2 style={{ margin: '0 0 24px', fontSize: 22, fontWeight: 700, color: '#0f172a' }}>
            Hồ Quang Minh
          </h2>

          <div
            style={{
              textAlign: 'left',
              display: 'flex',
              flexDirection: 'column',
              gap: 12,
              fontSize: 13,
            }}
          >
            <div style={{ display: 'flex', borderBottom: '1px solid #f1f5f9', paddingBottom: 8 }}>
              <span style={{ width: 130, fontWeight: 600, color: '#475569' }}>Mã sinh viên:</span>
              <span
                style={{
                  fontWeight: 500,
                  color: '#0f172a',
                  fontFamily: 'JetBrains Mono, monospace',
                }}
              >
                B23DCAT191
              </span>
            </div>

            <div style={{ display: 'flex', borderBottom: '1px solid #f1f5f9', paddingBottom: 8 }}>
              <span style={{ width: 130, fontWeight: 600, color: '#475569' }}>Email:</span>
              <span style={{ fontWeight: 500, color: '#0f172a' }}>
                hoquangminh.ptit@gmail.com
              </span>
            </div>

            <div style={{ display: 'flex', borderBottom: '1px solid #f1f5f9', paddingBottom: 8 }}>
              <span style={{ width: 130, fontWeight: 600, color: '#475569' }}>Github:</span>
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                style={{ fontWeight: 600, color: '#10b981', textDecoration: 'none' }}
              >
                github.com/hoquangminh
              </a>
            </div>

            <div style={{ display: 'flex', borderBottom: '1px solid #f1f5f9', paddingBottom: 8 }}>
              <span style={{ width: 130, fontWeight: 600, color: '#475569' }}>Figma:</span>
              <a
                href="https://www.figma.com/make/KEtOeNJR2Pr7i26BpTBp1h/Web-Dashboard-for-Smart-Home?t=R8WZl4cHYofAipV2-1"
                target="_blank"
                rel="noreferrer"
                style={{
                  fontWeight: 600,
                  color: '#10b981',
                  textDecoration: 'none',
                  wordBreak: 'break-all',
                }}
              >
                figma.com/Smart-Home-IoT
              </a>
            </div>

            <div style={{ display: 'flex', paddingBottom: 4 }}>
              <span style={{ width: 130, fontWeight: 600, color: '#475569' }}>
                PDF mô tả dự án:
              </span>
              <a
                href="https://docs.google.com/document/d/16NcV1QJZQwDhUDfzcMdLq3gxnC9QtAtn/edit?usp=drive_link&ouid=109534491001969593101&rtpof=true&sd=true"
                target="_blank"
                rel="noreferrer"
                style={{ fontWeight: 600, color: '#2563eb', textDecoration: 'underline' }}
              >
                Xem tại đây
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
