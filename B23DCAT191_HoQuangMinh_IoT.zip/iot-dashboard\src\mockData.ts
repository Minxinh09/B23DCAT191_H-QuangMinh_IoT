import type { ChartPoint, SensorReading, DeviceLog } from './types'

export const API_BASE_URL = 'http://localhost:5000'

export const formatDateTime = (date: Date): string => {
  const day = String(date.getDate()).padStart(2, '0')
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const year = date.getFullYear()
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')
  return `${day}/${month}/${year} ${hours}:${minutes}`
}

export const defaultChartData: ChartPoint[] = [
  { t: '06:00', temp: 24.2, humidity: 64, light: 120 },
  { t: '08:00', temp: 25.1, humidity: 65, light: 280 },
  { t: '10:00', temp: 26.3, humidity: 66, light: 410 },
  { t: '12:00', temp: 27.8, humidity: 62, light: 520 },
  { t: '14:00', temp: 28.4, humidity: 60, light: 490 },
  { t: '16:00', temp: 27.1, humidity: 63, light: 380 },
  { t: '18:00', temp: 26.0, humidity: 67, light: 210 },
  { t: '20:00', temp: 25.3, humidity: 69, light: 80 },
]

export const generateFallbackSensorHistory = (): SensorReading[] => {
  const sensorConfigs = [
    { name: 'Cảm biến Nhiệt độ DHT11', type: 'TEMPERATURE' as const, unit: '°C', base: 25, range: 4 },
    { name: 'Cảm biến Độ ẩm DHT11', type: 'HUMIDITY' as const, unit: '%', base: 60, range: 12 },
    { name: 'Cảm biến Ánh sáng LDR 4-pin', type: 'LIGHT' as const, unit: 'Lux', base: 200, range: 350 },
  ]

  return Array.from({ length: 36 }, (_, i) => {
    const config = sensorConfigs[i % 3]
    const d = new Date(Date.now() - (36 - i) * 12 * 60 * 1000)
    const val = config.type === 'LIGHT'
      ? Math.floor(config.base + Math.random() * config.range)
      : +(config.base + Math.random() * config.range).toFixed(1)

    return {
      id: i + 1,
      sensorName: config.name,
      sensorType: config.type,
      value: val,
      unit: config.unit,
      time: formatDateTime(d),
    }
  })
}

export const generateFallbackDeviceHistory = (): DeviceLog[] => {
  const devices = ['Đèn', 'Quạt', 'Điều hòa']
  const statuses: ('SUCCESS' | 'TIMEOUT')[] = ['SUCCESS', 'SUCCESS', 'SUCCESS', 'TIMEOUT']
  const sampleUsers = ['hoquangminh', 'hoquangminh', 'admin_sys', 'hoquangminh', 'system_auto']
  return Array.from({ length: 28 }, (_, i) => {
    const d = new Date(Date.now() - (28 - i) * 20 * 60 * 1000)
    return {
      id: i + 1,
      device: devices[i % 3],
      action: i % 3 === 1 ? 'OFF' : 'ON',
      status: statuses[i % 4],
      triggeredBy: sampleUsers[i % sampleUsers.length],
      time: formatDateTime(d),
    }
  })
}
