import { useState, useEffect } from 'react'
import type { SensorReading } from '../types'
import { API_BASE_URL, generateFallbackSensorHistory } from '../mockData'
import { Header } from '../components/Header'
import {
  IconFilter,
  IconClock,
  IconChevronLeft,
  IconChevronRight,
} from '../components/Icons'

const initialRows = generateFallbackSensorHistory()

export function SensorHistoryPage() {
  const [rows, setRows] = useState<SensorReading[]>(initialRows)
  const [sensorTypeFilter, setSensorTypeFilter] = useState<string>('ALL')
  const [valueFilter, setValueFilter] = useState<string>('')
  const [timeFilter, setTimeFilter] = useState<string>('')
  const [page, setPage] = useState<number>(1)
  const [pageSize, setPageSize] = useState<number>(8)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/sensors/history`)
        if (res.ok) {
          const json = await res.json()
          if (json.success && Array.isArray(json.data)) {
            setRows(json.data)
          }
        }
      } catch {
        // Fallback already loaded
      }
    }
    fetchData()
  }, [])

  const filtered = rows.filter(row => {
    const matchesType = sensorTypeFilter === 'ALL' || row.sensorType === sensorTypeFilter
    const matchesTime = timeFilter === '' || row.time.toLowerCase().includes(timeFilter.toLowerCase())
    let matchesValue = true

    if (valueFilter.trim() !== '') {
      const term = valueFilter.trim()
      if (term.startsWith('>')) {
        const num = parseFloat(term.slice(1))
        if (!isNaN(num)) matchesValue = row.value > num
      } else if (term.startsWith('<')) {
        const num = parseFloat(term.slice(1))
        if (!isNaN(num)) matchesValue = row.value < num
      } else {
        matchesValue = String(row.value).includes(term)
      }
    }

    return matchesType && matchesTime && matchesValue
  })

  const effectivePageSize = Math.max(1, pageSize || 8)
  const totalPages = Math.ceil(filtered.length / effectivePageSize) || 1
  const paged = filtered.slice((page - 1) * effectivePageSize, page * effectivePageSize)

  useEffect(() => {
    setPage(1)
  }, [sensorTypeFilter, valueFilter, timeFilter, pageSize])

  return (
    <div>
      <Header title="Lịch sử Cảm biến" />

      <div
        style={{
          background: '#fff',
          borderRadius: 14,
          border: '1px solid #e8edf5',
          boxShadow: '0 1px 4px rgba(0,0,0,0.05)',
          overflow: 'hidden',
        }}
      >
        {/* Table Top Header & Filters */}
        <div
          style={{
            padding: '18px 24px 14px',
            borderBottom: '1px solid #f1f5f9',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 16,
            flexWrap: 'wrap',
          }}
        >
          <div>
            <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: '#0f172a' }}>
              Lịch sử Cảm biến
            </h2>
            <p style={{ margin: '2px 0 0', fontSize: 12, color: '#64748b' }}>
              Dữ liệu đọc từ các cảm biến nhiệt độ, độ ẩm và ánh sáng
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            {/* Sensor Type Filter */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: '#f8fafc',
                padding: '5px 10px',
                borderRadius: 8,
                border: '1px solid #e2e8f0',
              }}
            >
              <span style={{ color: '#2563eb', display: 'flex' }}>
                <IconFilter />
              </span>
              <span style={{ fontSize: 12, fontWeight: 500, color: '#64748b' }}>
                Loại cảm biến:
              </span>
              <select
                value={sensorTypeFilter}
                onChange={e => setSensorTypeFilter(e.target.value)}
                style={{
                  border: 'none',
                  background: 'transparent',
                  fontSize: 12,
                  color: '#1e293b',
                  outline: 'none',
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                <option value="ALL">Tất cả cảm biến</option>
                <option value="TEMPERATURE">Cảm biến Nhiệt độ</option>
                <option value="HUMIDITY">Cảm biến Độ ẩm</option>
                <option value="LIGHT">Cảm biến Ánh sáng</option>
              </select>
            </div>

            {/* Value Filter */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: '#f8fafc',
                padding: '5px 10px',
                borderRadius: 8,
                border: '1px solid #e2e8f0',
              }}
            >
              <span style={{ fontSize: 12, fontWeight: 500, color: '#64748b' }}>Giá trị:</span>
              <input
                type="text"
                value={valueFilter}
                onChange={e => setValueFilter(e.target.value)}
                placeholder="Ví dụ: 25.5 hoặc >30"
                style={{
                  border: 'none',
                  background: 'transparent',
                  fontSize: 12,
                  color: '#1e293b',
                  outline: 'none',
                  width: 125,
                }}
              />
            </div>

            {/* Time Filter */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                background: '#f8fafc',
                padding: '5px 10px',
                borderRadius: 8,
                border: '1px solid #e2e8f0',
              }}
            >
              <span style={{ color: '#2563eb', display: 'flex' }}>
                <IconClock />
              </span>
              <span style={{ fontSize: 12, fontWeight: 500, color: '#64748b' }}>Thời gian:</span>
              <input
                type="text"
                value={timeFilter}
                onChange={e => setTimeFilter(e.target.value)}
                placeholder="Ví dụ: 26/08/2026 hoặc 22:56"
                style={{
                  border: 'none',
                  background: 'transparent',
                  fontSize: 12,
                  color: '#1e293b',
                  outline: 'none',
                  width: 165,
                }}
              />
            </div>

            {/* Clear filter button */}
            {(sensorTypeFilter !== 'ALL' || valueFilter || timeFilter) && (
              <button
                onClick={() => {
                  setSensorTypeFilter('ALL')
                  setValueFilter('')
                  setTimeFilter('')
                }}
                style={{
                  padding: '5px 10px',
                  borderRadius: 8,
                  border: '1px solid #cbd5e1',
                  background: '#fff',
                  color: '#64748b',
                  fontSize: 12,
                  fontWeight: 500,
                  cursor: 'pointer',
                }}
              >
                Xóa lọc
              </button>
            )}
          </div>
        </div>

        {/* Table */}
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f8fafc' }}>
                <th
                  style={{
                    padding: '11px 20px',
                    textAlign: 'left',
                    fontSize: 12,
                    fontWeight: 600,
                    color: '#64748b',
                    borderBottom: '1px solid #e8edf5',
                  }}
                >
                  ID
                </th>
                <th
                  style={{
                    padding: '11px 20px',
                    textAlign: 'left',
                    fontSize: 12,
                    fontWeight: 600,
                    color: '#64748b',
                    borderBottom: '1px solid #e8edf5',
                  }}
                >
                  TÊN CẢM BIẾN
                </th>
                <th
                  style={{
                    padding: '11px 20px',
                    textAlign: 'left',
                    fontSize: 12,
                    fontWeight: 600,
                    color: '#64748b',
                    borderBottom: '1px solid #e8edf5',
                  }}
                >
                  GIÁ TRỊ ĐO
                </th>
                <th
                  style={{
                    padding: '11px 20px',
                    textAlign: 'left',
                    fontSize: 12,
                    fontWeight: 600,
                    color: '#64748b',
                    borderBottom: '1px solid #e8edf5',
                  }}
                >
                  THỜI GIAN THU THẬP
                </th>
              </tr>
            </thead>
            <tbody>
              {paged.length === 0 ? (
                <tr>
                  <td
                    colSpan={4}
                    style={{
                      padding: '40px 20px',
                      textAlign: 'center',
                      color: '#94a3b8',
                      fontSize: 14,
                    }}
                  >
                    Không tìm thấy kết quả nào trùng khớp
                  </td>
                </tr>
              ) : (
                paged.map((row, idx) => (
                  <tr key={row.id} style={{ background: idx % 2 === 0 ? '#fff' : '#fafbfc' }}>
                    <td
                      style={{
                        padding: '12px 20px',
                        fontSize: 13,
                        borderBottom: '1px solid #f1f5f9',
                        fontFamily: 'JetBrains Mono, monospace',
                        color: '#94a3b8',
                      }}
                    >
                      #{String(row.id).padStart(3, '0')}
                    </td>
                    <td
                      style={{
                        padding: '12px 20px',
                        fontSize: 13,
                        borderBottom: '1px solid #f1f5f9',
                        fontWeight: 600,
                        color: '#1e293b',
                      }}
                    >
                      {row.sensorName}
                    </td>
                    <td
                      style={{
                        padding: '12px 20px',
                        fontSize: 13,
                        borderBottom: '1px solid #f1f5f9',
                      }}
                    >
                      <span
                        style={{
                          fontWeight: 700,
                          fontSize: 14,
                          color:
                            row.sensorType === 'TEMPERATURE'
                              ? '#ea580c'
                              : row.sensorType === 'HUMIDITY'
                              ? '#0284c7'
                              : '#ca8a04',
                        }}
                      >
                        {row.value} {row.unit}
                      </span>
                    </td>
                    <td
                      style={{
                        padding: '12px 20px',
                        fontSize: 13,
                        borderBottom: '1px solid #f1f5f9',
                        fontFamily: 'JetBrains Mono, monospace',
                        color: '#64748b',
                      }}
                    >
                      {row.time}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination & Page Size Control */}
        <div
          style={{
            padding: '12px 24px',
            borderTop: '1px solid #f1f5f9',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 16,
            flexWrap: 'wrap',
          }}
        >
          {/* Ô nhập số bản ghi trên 1 trang */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 13, color: '#64748b' }}>Hiển thị:</span>
            <input
              type="number"
              min={1}
              max={100}
              value={pageSize || ''}
              onChange={e => {
                const val = parseInt(e.target.value, 10)
                setPageSize(isNaN(val) ? 0 : Math.max(1, Math.min(100, val)))
              }}
              style={{
                width: 54,
                padding: '4px 6px',
                borderRadius: 6,
                border: '1px solid #cbd5e1',
                textAlign: 'center',
                fontSize: 13,
                fontWeight: 600,
                color: '#1e293b',
                outline: 'none',
              }}
            />
            <span style={{ fontSize: 13, color: '#64748b' }}>
              bản ghi / trang (Tổng: <strong>{filtered.length}</strong>)
            </span>
          </div>

          {/* Nút chuyển trang */}
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span style={{ fontSize: 13, color: '#64748b', marginRight: 4 }}>
              Trang {page} / {totalPages}
            </span>
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                border: '1px solid #e2e8f0',
                background: '#fff',
                cursor: page === 1 ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: page === 1 ? 0.5 : 1,
              }}
            >
              <IconChevronLeft />
            </button>
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              const n = i + 1
              return (
                <button
                  key={n}
                  onClick={() => setPage(n)}
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 8,
                    border: `1px solid ${n === page ? '#2563eb' : '#e2e8f0'}`,
                    background: n === page ? '#2563eb' : '#fff',
                    color: n === page ? '#fff' : '#475569',
                    cursor: 'pointer',
                    fontSize: 13,
                    fontWeight: n === page ? 600 : 400,
                  }}
                >
                  {n}
                </button>
              )
            })}
            <button
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
              disabled={page === totalPages || totalPages === 0}
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                border: '1px solid #e2e8f0',
                background: '#fff',
                cursor: page === totalPages || totalPages === 0 ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: page === totalPages || totalPages === 0 ? 0.5 : 1,
              }}
            >
              <IconChevronRight />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
