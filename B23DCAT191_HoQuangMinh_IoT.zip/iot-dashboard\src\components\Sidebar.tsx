import type { Page, User } from '../types'
import {
  IconLogoHome,
  IconNavDashboard,
  IconNavSensors,
  IconNavDevices,
  IconUser,
  IconLogout,
} from './Icons'

interface SidebarProps {
  page: Page
  setPage: (p: Page) => void
  user: User
  onLogout: () => void
}

const navList: { id: Page; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <IconNavDashboard /> },
  { id: 'sensor-history', label: 'Lịch sử Cảm biến', icon: <IconNavSensors /> },
  { id: 'device-history', label: 'Lịch sử Bật Tắt', icon: <IconNavDevices /> },
  { id: 'profile', label: 'Profile', icon: <IconUser size={18} /> },
]

export function Sidebar({ page, setPage, user, onLogout }: SidebarProps) {
  return (
    <aside style={{
      width: 240, minHeight: '100vh', background: '#1e293b',
      display: 'flex', flexDirection: 'column', flexShrink: 0,
    }}>
      {/* Brand Header */}
      <div style={{ padding: '24px 20px 16px', borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 34, height: 34, borderRadius: 8,
            background: 'linear-gradient(135deg, #2563eb, #1d4ed8)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <IconLogoHome />
          </div>
          <div>
            <div style={{ color: '#fff', fontWeight: 700, fontSize: 13, lineHeight: 1.2 }}>
              Smart Home
            </div>
            <div style={{ color: '#64748b', fontSize: 11 }}>
              IoT Dashboard
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav style={{ flex: 1, padding: '12px 10px' }}>
        <div style={{
          fontSize: 10, fontWeight: 600, color: '#475569',
          letterSpacing: '0.08em', textTransform: 'uppercase',
          padding: '8px 10px 6px',
        }}>
          Điều hướng
        </div>

        {navList.map(item => {
          const isActive = page === item.id
          return (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 12px', borderRadius: 8, border: 'none', cursor: 'pointer',
                background: isActive ? 'rgba(37,99,235,0.18)' : 'transparent',
                color: isActive ? '#60a5fa' : '#94a3b8',
                fontFamily: 'inherit', fontSize: 14, fontWeight: isActive ? 600 : 400,
                marginBottom: 2, textAlign: 'left', transition: 'all 0.15s',
              }}
            >
              {item.icon}
              <span>{item.label}</span>
              {isActive && (
                <span style={{
                  marginLeft: 'auto', width: 6, height: 6,
                  borderRadius: '50%', background: '#60a5fa',
                }} />
              )}
            </button>
          )
        })}
      </nav>

      {/* User Footer */}
      <div style={{
        padding: '16px 14px', borderTop: '1px solid rgba(255,255,255,0.07)',
        background: 'rgba(0,0,0,0.15)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
          <div>
            <div style={{ color: '#e2e8f0', fontWeight: 600, fontSize: 12 }}>
              {user.fullName}
            </div>
            <div style={{ color: '#64748b', fontSize: 10 }}>
              @{user.username} · {user.role}
            </div>
          </div>
        </div>

        <button
          onClick={onLogout}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
            gap: 6, padding: '6px 10px', borderRadius: 6,
            border: '1px solid rgba(255,255,255,0.1)', background: 'transparent',
            color: '#f87171', fontSize: 12, cursor: 'pointer',
          }}
        >
          <IconLogout />
          <span>Đăng xuất</span>
        </button>
      </div>
    </aside>
  )
}
