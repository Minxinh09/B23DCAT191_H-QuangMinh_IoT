import { useState, useEffect, type ReactNode } from 'react'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts'
import type { ChartPoint, DeviceState, DeviceStatusState } from '../types'
import { API_BASE_URL, defaultChartData } from '../mockData'
import { Header } from '../components/Header'
import {
  IconThermometer,
  IconDroplets,
  IconSun,
  IconSpinner,
  IconLightBulb,
  IconFan,
  IconAirConditioner,
} from '../components/Icons'

function DeviceControlItem({
  name,
  icon,
  status,
  onToggle,
}: {
  name: string
  icon: ReactNode
  status: DeviceStatusState
  onToggle: () => void
}) {
  const isPending = status === 'PENDING'
  const isOn = status === 'ON'

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '12px 16px',
        background: isPending ? '#fefce8' : isOn ? '#eff6ff' : '#f8fafc',
        borderRadius: 12,
        border: `1px solid ${isPending ? '#fef08a' : isOn ? '#bfdbfe' : '#e2e8f0'}`,
        transition: 'all 0.2s',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div
          style={{
            width: 40,
            height: 40,
            borderRadius: 10,
            background: isPending ? '#eab308' : isOn ? '#2563eb' : '#e2e8f0',
            color: isPending || isOn ? '#fff' : '#64748b',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'all 0.2s',
          }}
        >
          {isPending ? <IconSpinner /> : icon}
        </div>
        <div>
          <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: '#1e293b' }}>{name}</p>
          <p
            style={{
              margin: '2px 0 0',
              fontSize: 12,
              color: isPending ? '#ca8a04' : isOn ? '#2563eb' : '#94a3b8',
              fontWeight: 600,
            }}
          >
            {isPending ? 'ĐANG CHỜ...' : isOn ? 'ĐANG BẬT' : 'ĐANG TẮT'}
          </p>
        </div>
      </div>

      {/* Switch công tắc to rõ ràng, cân đối */}
      <button
        onClick={onToggle}
        disabled={isPending}
        title={isOn ? `Tắt ${name}` : `Bật ${name}`}
        style={{
          width: 52,
          height: 28,
          borderRadius: 14,
          border: 'none',
          cursor: isPending ? 'not-allowed' : 'pointer',
          background: isPending ? '#eab308' : isOn ? '#2563eb' : '#cbd5e1',
          position: 'relative',
          transition: 'background 0.25s',
          padding: 0,
          outline: 'none',
          flexShrink: 0,
        }}
      >
        <span
          style={{
            position: 'absolute',
            top: 3,
            left: isOn ? 26 : 3,
            width: 22,
            height: 22,
            borderRadius: '50%',
            background: '#ffffff',
            boxShadow: '0 2px 4px rgba(0,0,0,0.22)',
            transition: 'left 0.22s ease-in-out',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {isPending && (
            <span
              style={{
                width: 8,
                height: 8,
                borderRadius: '50%',
                background: '#ca8a04',
              }}
            />
          )}
        </span>
      </button>
    </div>
  )
}

function MetricSummaryCard({
  icon,
  iconBg,
  iconColor,
  label,
  value,
  unit,
  avgValue,
  badgeBg,
  badgeBorder,
  badgeColor,
}: {
  icon: ReactNode
  iconBg: string
  iconColor: string
  label: string
  value: string | number
  unit: string
  avgValue: string | number
  badgeBg: string
  badgeBorder: string
  badgeColor: string
}) {
  return (
    <div
      style={{
        flex: 1,
        minWidth: 0,
        background: '#ffffff',
        borderRadius: 14,
        padding: '16px 20px',
        border: '1px solid #e8edf5',
        boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
        display: 'flex',
        alignItems: 'center',
        gap: 16,
      }}
    >
      <div
        style={{
          width: 48,
          height: 48,
          borderRadius: 12,
          background: iconBg,
          color: iconColor,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
        }}
      >
        {icon}
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <p
          style={{
            margin: 0,
            fontSize: 12,
            fontWeight: 600,
            color: iconColor,
            textTransform: 'uppercase',
            letterSpacing: '0.04em',
          }}
        >
          {label}
        </p>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 4 }}>
          <span
            style={{
              fontSize: 26,
              fontWeight: 700,
              color: '#0f172a',
              lineHeight: 1,
              fontFamily: 'JetBrains Mono, Inter, sans-serif',
            }}
          >
            {value}
          </span>
          <span style={{ fontSize: 14, color: '#64748b', fontWeight: 600 }}>{unit}</span>
          <span
            style={{
              marginLeft: 'auto',
              fontSize: 11,
              fontWeight: 600,
              color: badgeColor,
              background: badgeBg,
              padding: '3px 8px',
              borderRadius: 6,
              border: `1px solid ${badgeBorder}`,
              whiteSpace: 'nowrap',
            }}
          >
            TB: {avgValue} {unit}
          </span>
        </div>
      </div>
    </div>
  )
}

export function DashboardPage({
  addToast,
}: {
  addToast: (msg: string, type: 'success' | 'error') => void
}) {
  const [deviceStates, setDeviceStates] = useState<DeviceState>(() => {
    const saved = localStorage.getItem('iot_device_states')
    return saved ? JSON.parse(saved) : { light: 'ON', fan: 'OFF', ac: 'ON' }
  })

  const [sensorValues, setSensorValues] = useState({
    temp: 26.0,
    humidity: 67.1,
    light: 450,
  })

  const [chartData, setChartData] = useState<ChartPoint[]>(defaultChartData)

  const avgTemp = (
    chartData.reduce((acc, cur) => acc + cur.temp, 0) / (chartData.length || 1)
  ).toFixed(1)
  const avgHum = (
    chartData.reduce((acc, cur) => acc + cur.humidity, 0) / (chartData.length || 1)
  ).toFixed(1)
  const avgLight = Math.round(
    chartData.reduce((acc, cur) => acc + cur.light, 0) / (chartData.length || 1)
  )

  useEffect(() => {
    localStorage.setItem('iot_device_states', JSON.stringify(deviceStates))
  }, [deviceStates])

  const [isHardwareOnline, setIsHardwareOnline] = useState<boolean>(true)

  useEffect(() => {
    const fetchLatest = async () => {
      try {
        const res = await fetch(`${API_BASE_URL}/api/sensors/latest`)
        if (res.ok) {
          const json = await res.json()
          if (json.success && json.data) {
            setSensorValues({
              temp: json.data.temperature ?? json.data.temp ?? 26.0,
              humidity: json.data.humidity ?? 67.1,
              light: json.data.light_lux ?? json.data.light ?? 450,
            })
            // Cập nhật các điểm dữ liệu thời gian thực có giờ:phút:giây
            if (Array.isArray(json.data.chartData) && json.data.chartData.length > 0) {
              setChartData(json.data.chartData)
            }
            // Nhận diện mạch thật đang cắm hay đã rút
            if (typeof json.data.isHardwareOnline === 'boolean') {
              setIsHardwareOnline(json.data.isHardwareOnline)
            }
          }
        } else {
          setIsHardwareOnline(false)
        }
      } catch {
        setIsHardwareOnline(false)
      }
    }
    fetchLatest()
    const timer = setInterval(fetchLatest, 3000)
    return () => clearInterval(timer)
  }, [])

  const handleToggle = async (key: 'light' | 'fan' | 'ac') => {
    const current = deviceStates[key]
    const next = current === 'ON' ? 'OFF' : 'ON'

    setDeviceStates(prev => ({ ...prev, [key]: 'PENDING' }))

    const deviceApiNames: Record<'light' | 'fan' | 'ac', string> = {
      light: 'LIGHT',
      fan: 'FAN',
      ac: 'AIR_CONDITIONER',
    }
    const deviceLabels: Record<'light' | 'fan' | 'ac', string> = {
      light: 'Đèn',
      fan: 'Quạt',
      ac: 'Điều hòa',
    }

    let isHandled = false
    const timeoutId = setTimeout(() => {
      if (!isHandled) {
        setDeviceStates(prev => ({ ...prev, [key]: current }))
        addToast(
          `🔴 Lỗi: Thiết bị ${deviceLabels[key]} không phản hồi (Quá thời gian chờ 5s)!`,
          'error'
        )
      }
    }, 5000)

    const actionVerb = next === 'ON' ? 'Bật' : 'Tắt'

    try {
      const currentUser = (() => {
        try {
          const u = localStorage.getItem('iot_current_user')
          return u ? JSON.parse(u).username : 'hoquangminh'
        } catch {
          return 'hoquangminh'
        }
      })()

      const res = await fetch(`${API_BASE_URL}/api/devices/control`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          device: deviceApiNames[key],
          action: next,
          triggeredBy: currentUser,
        }),
      })

      if (res.ok) {
        isHandled = true
        clearTimeout(timeoutId)
        setDeviceStates(prev => ({ ...prev, [key]: next }))
        addToast(`🟢 ${actionVerb} thiết bị ${deviceLabels[key]} thành công!`, 'success')
      } else {
        const errorJson = await res.json().catch(() => ({}))
        isHandled = true
        clearTimeout(timeoutId)
        setDeviceStates(prev => ({ ...prev, [key]: current }))
        addToast(
          `🔴 ${errorJson.message || `Lỗi kết nối tới thiết bị ${deviceLabels[key]}!`}`,
          'error'
        )
      }
    } catch {
      // Khi mất kết nối hoặc không nhận được phản hồi
      isHandled = true
      clearTimeout(timeoutId)
      setDeviceStates(prev => ({ ...prev, [key]: current }))
      addToast(`🔴 Không thể kết nối tới mạch phần cứng ${deviceLabels[key]}!`, 'error')
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <Header title="Hệ thống giám sát và điều khiển" isConnected={isHardwareOnline} />

      {/* KHỐI 1: BẢNG ĐIỀU KHIỂN THIẾT BỊ (3 cột công tắc to, cân đối) */}
      <div
        style={{
          background: '#ffffff',
          borderRadius: 14,
          padding: '14px 20px',
          border: '1px solid #e8edf5',
          boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
        }}
      >
        <div
          style={{
            marginBottom: 10,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 15, fontWeight: 700, color: '#0f172a' }}>
              Bảng điều khiển thiết bị
            </span>
            <span
              style={{
                fontSize: 11,
                background: '#f1f5f9',
                color: '#64748b',
                padding: '2px 8px',
                borderRadius: 12,
                fontWeight: 500,
              }}
            >
              Phản hồi tức thì · Timeout 5s
            </span>
          </div>
          <span style={{ fontSize: 12, color: '#94a3b8' }}>
            Nhấp công tắc để Bật/Tắt thiết bị
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
          <DeviceControlItem
            name="Đèn Chiếu Sáng"
            icon={<IconLightBulb />}
            status={deviceStates.light}
            onToggle={() => handleToggle('light')}
          />
          <DeviceControlItem
            name="Quạt Thông Gió"
            icon={<IconFan />}
            status={deviceStates.fan}
            onToggle={() => handleToggle('fan')}
          />
          <DeviceControlItem
            name="Điều Hòa Không Khí"
            icon={<IconAirConditioner />}
            status={deviceStates.ac}
            onToggle={() => handleToggle('ac')}
          />
        </div>
      </div>

      {/* KHỐI 2: 3 THẺ HIỂN THỊ CHỈ SỐ MÔI TRƯỜNG TÁCH RIÊNG */}
      <div style={{ display: 'flex', gap: 14 }}>
        <MetricSummaryCard
          icon={<IconThermometer />}
          iconBg="#fff7ed"
          iconColor="#ea580c"
          label="Nhiệt độ hiện tại"
          value={sensorValues.temp.toFixed(1)}
          unit="°C"
          avgValue={avgTemp}
          badgeBg="#fff7ed"
          badgeBorder="#ffedd5"
          badgeColor="#ea580c"
        />
        <MetricSummaryCard
          icon={<IconDroplets />}
          iconBg="#f0f9ff"
          iconColor="#0284c7"
          label="Độ ẩm hiện tại"
          value={sensorValues.humidity.toFixed(1)}
          unit="%"
          avgValue={avgHum}
          badgeBg="#f0f9ff"
          badgeBorder="#e0f2fe"
          badgeColor="#0284c7"
        />
        <MetricSummaryCard
          icon={<IconSun />}
          iconBg="#fefce8"
          iconColor="#ca8a04"
          label="Cường độ ánh sáng"
          value={sensorValues.light}
          unit="Lux"
          avgValue={avgLight}
          badgeBg="#fefce8"
          badgeBorder="#fef08a"
          badgeColor="#ca8a04"
        />
      </div>

      {/* KHỐI 3: KHỐI BIỂU ĐỒ RIÊNG BIỆT (3 Lines Recharts) */}
      <div
        style={{
          background: '#ffffff',
          borderRadius: 14,
          padding: '16px 20px',
          border: '1px solid #e8edf5',
          boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 12,
          }}
        >
          <div>
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: '#0f172a' }}>
              Biểu đồ xu hướng Môi trường theo thời gian
            </h3>
            <p style={{ margin: '2px 0 0', fontSize: 12, color: '#64748b' }}>
              Theo dõi đồng bộ Nhiệt độ (°C), Độ ẩm (%) và Ánh sáng (Lux) qua trục đo kép
            </p>
          </div>
        </div>

        <ResponsiveContainer width="100%" height={320}>
          <LineChart data={chartData} margin={{ top: 10, right: 16, left: -6, bottom: 6 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
            <XAxis
              dataKey="t"
              tick={{ fontSize: 11, fill: '#94a3b8' }}
              tickLine={false}
              axisLine={false}
            />
            {/* Trục trái dành cho Nhiệt độ & Độ ẩm: dải zoom tự động theo dữ liệu để thấy rõ độ nhấp nhô biến động */}
            <YAxis
              yAxisId="left"
              domain={['dataMin - 5', 'dataMax + 5']}
              tick={{ fontSize: 11, fill: '#64748b' }}
              tickLine={false}
              axisLine={false}
              unit=""
            />
            {/* Trục phải dành cho Ánh sáng (Lux): dải zoom tự động theo dữ liệu thực tế */}
            <YAxis
              yAxisId="right"
              orientation="right"
              domain={['dataMin - 30', 'dataMax + 30']}
              tick={{ fontSize: 11, fill: '#ca8a04' }}
              tickLine={false}
              axisLine={false}
              unit=" Lux"
            />
            <Tooltip
              contentStyle={{
                fontSize: 12,
                padding: '6px 10px',
                borderRadius: 8,
                border: '1px solid #e2e8f0',
                boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
              }}
            />
            <Legend
              verticalAlign="top"
              align="right"
              height={30}
              iconType="circle"
              wrapperStyle={{ fontSize: 12, fontWeight: 600 }}
            />
            {/* Đường Ánh sáng ở trên */}
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="light"
              stroke="#eab308"
              strokeWidth={2.5}
              dot={{ r: 3.5, fill: '#eab308' }}
              activeDot={{ r: 5 }}
              name="Ánh sáng (Lux)"
            />
            {/* 2 Đường Nhiệt độ và Độ ẩm ở nửa dưới */}
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="temp"
              stroke="#f97316"
              strokeWidth={2.5}
              dot={{ r: 3.5, fill: '#f97316' }}
              activeDot={{ r: 5 }}
              name="Nhiệt độ (°C)"
            />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="humidity"
              stroke="#0ea5e9"
              strokeWidth={2.5}
              dot={{ r: 3.5, fill: '#0ea5e9' }}
              activeDot={{ r: 5 }}
              name="Độ ẩm (%)"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
