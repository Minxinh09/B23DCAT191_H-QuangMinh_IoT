import express from 'express'
import cors from 'cors'
import mqtt from 'mqtt'
import swaggerUi from 'swagger-ui-express'

const app = express()
const PORT = 5000

// Cấu hình Middleware
app.use(cors())
app.use(express.json())

// ─── 1. CẤU HÌNH MQTT BROKER KHỚP 100% VỚI CODE ESP8266 ─────────────
const MQTT_BROKER_URL = 'mqtt://127.0.0.1:1884'
const MQTT_OPTIONS = {
  username: 'minh',
  password: '2005',
  clientId: `NodeServer_${Math.random().toString(16).substring(2, 8)}`,
  reconnectPeriod: 3000,
  connectTimeout: 5000,
}

const TOPIC_TELEMETRY = 'data_sensor'       // Topic nhận dữ liệu cảm biến từ ESP
const TOPIC_CONTROL   = 'device_control'     // Topic phát lệnh bật tắt xuống ESP
const TOPIC_STATUS    = 'device_response'    // Topic nhận phản hồi ACK từ ESP

// ─── 2. BỘ NHỚ LƯU TRỮ TRONG RAM (IN-MEMORY STORAGE) ─────────────────
// Định dạng ngày giờ: DD/MM/YYYY HH:mm
const formatDateTime = (d = new Date()) => {
  const day = String(d.getDate()).padStart(2, '0')
  const month = String(d.getMonth() + 1).padStart(2, '0')
  const year = d.getFullYear()
  const hours = String(d.getHours()).padStart(2, '0')
  const minutes = String(d.getMinutes()).padStart(2, '0')
  return `${day}/${month}/${year} ${hours}:${minutes}`
}

// Định dạng thời gian chi tiết theo giây: HH:mm:ss
const formatTimeSeconds = (d = new Date()) => {
  const hours = String(d.getHours()).padStart(2, '0')
  const minutes = String(d.getMinutes()).padStart(2, '0')
  const seconds = String(d.getSeconds()).padStart(2, '0')
  return `${hours}:${minutes}:${seconds}`
}

let latestSensor = {
  temperature: 26.0,
  humidity: 65.0,
  light_lux: 400,
  time: formatDateTime(),
}

// Lưu các điểm biểu đồ theo thời gian thực (giữ 15 điểm gần nhất, có biến động tự nhiên nếu chưa có số đo)
let recentChartPoints = Array.from({ length: 12 }, (_, i) => {
  const d = new Date(Date.now() - (12 - i) * 6 * 1000)
  return {
    t: formatTimeSeconds(d),
    temp: +(26.5 + Math.sin(i * 0.8) * 1.5).toFixed(1),
    humidity: +(64.0 + Math.cos(i * 0.7) * 4.0).toFixed(1),
    light: Math.round(420 + Math.sin(i * 0.9) * 85),
  }
})

// Lưu thời điểm nhận gói tin cuối cùng từ ESP8266
let lastHardwareHeartbeat = 0

// Lưu lịch sử cảm biến
let sensorHistory = []
let sensorIdCounter = 1

// Ánh xạ tên thiết bị sang Tiếng Việt chuẩn
const deviceNameMap = {
  LIGHT: 'Đèn',
  FAN: 'Quạt',
  AC: 'Điều hòa',
  AIR_CONDITIONER: 'Điều hòa',
  ALL: 'Tất cả thiết bị',
}

// Lưu lịch sử bật/tắt thiết bị (đồng nhất tên người thực hiện là hoquangminh)
const devicesList = ['Đèn', 'Quạt', 'Điều hòa']
const actionsList = ['ON', 'OFF']
const statusesList = ['SUCCESS', 'SUCCESS', 'TIMEOUT']

let deviceHistory = Array.from({ length: 16 }, (_, i) => {
  const d = new Date(Date.now() - (16 - i) * 15 * 60 * 1000)
  return {
    id: i + 1,
    device: devicesList[i % 3],
    action: actionsList[i % 2],
    status: statusesList[i % 3],
    triggeredBy: 'hoquangminh',
    time: formatDateTime(d),
  }
}).reverse()

let deviceIdCounter = 17

// Danh sách chờ phản hồi ACK (cho cơ chế Timeout 5s)
// key: "DEVICE_ACTION" -> { resolve, timeoutId }
const pendingCommands = new Map()

// ─── 3. KẾT NỐI MQTT BROKER ──────────────────────────────────────────
console.log(`[MQTT] Đang kết nối tới Broker ${MQTT_BROKER_URL}...`)
const mqttClient = mqtt.connect(MQTT_BROKER_URL, MQTT_OPTIONS)

mqttClient.on('connect', () => {
  console.log('✅ [MQTT] Đã kết nối thành công tới MQTT Broker!')
  
  // Lắng nghe dữ liệu cảm biến & phản hồi ACK từ ESP8266
  mqttClient.subscribe([TOPIC_TELEMETRY, TOPIC_STATUS], (err) => {
    if (!err) {
      console.log(`📡 [MQTT] Đã đăng ký lắng nghe: "${TOPIC_TELEMETRY}" và "${TOPIC_STATUS}"`)
    } else {
      console.error('❌ [MQTT] Lỗi subscribe:', err)
    }
  })
})

mqttClient.on('error', (err) => {
  console.error('⚠️ [MQTT] Lỗi kết nối Broker:', err.message)
})

mqttClient.on('offline', () => {
  console.warn('⚠️ [MQTT] Broker offline, đang chờ kết nối lại...')
})

// Xử lý gói tin MQTT nhận được
mqttClient.on('message', (topic, payload) => {
  const messageStr = payload.toString()

  // 3.1 Nhận dữ liệu cảm biến từ ESP
  if (topic === TOPIC_TELEMETRY) {
    try {
      const data = JSON.parse(messageStr)
      lastHardwareHeartbeat = Date.now() // Cập nhật thời điểm ESP8266 vừa gửi tin
      latestSensor = {
        temperature: Number(data.temperature ?? latestSensor.temperature),
        humidity: Number(data.humidity ?? latestSensor.humidity),
        light_lux: Number(data.light_lux ?? latestSensor.light_lux),
        time: formatDateTime(),
      }

      // Thêm điểm dữ liệu mới vào biểu đồ thời gian thực (giữ 15 điểm gần nhất)
      recentChartPoints.push({
        t: formatTimeSeconds(),
        temp: latestSensor.temperature,
        humidity: latestSensor.humidity,
        light: latestSensor.light_lux,
      })
      if (recentChartPoints.length > 15) {
        recentChartPoints.shift()
      }

      const nowStr = formatDateTime()

      // Tách thành 3 bản ghi riêng cho bảng lịch sử cảm biến
      sensorHistory.unshift(
        {
          id: sensorIdCounter++,
          sensorName: 'Cảm biến Nhiệt độ DHT11',
          sensorType: 'TEMPERATURE',
          value: latestSensor.temperature,
          unit: '°C',
          time: nowStr,
        },
        {
          id: sensorIdCounter++,
          sensorName: 'Cảm biến Độ ẩm DHT11',
          sensorType: 'HUMIDITY',
          value: latestSensor.humidity,
          unit: '%',
          time: nowStr,
        },
        {
          id: sensorIdCounter++,
          sensorName: 'Cảm biến Ánh sáng LDR 4-pin',
          sensorType: 'LIGHT',
          value: latestSensor.light_lux,
          unit: 'Lux',
          time: nowStr,
        }
      )

      // Giữ tối đa 300 bản ghi trong RAM
      if (sensorHistory.length > 300) {
        sensorHistory = sensorHistory.slice(0, 300)
      }

      console.log(`🌡️ [Sensor] Temp: ${latestSensor.temperature}°C | Hum: ${latestSensor.humidity}% | Lux: ${latestSensor.light_lux}`)
    } catch (e) {
      console.error('[MQTT] Lỗi parse JSON từ data_sensor:', e.message)
    }
  }

  // 3.2 Nhận phản hồi ACK từ ESP8266 khi thực hiện xong lệnh
  if (topic === TOPIC_STATUS) {
    try {
      const resp = JSON.parse(messageStr)
      // resp dạng: { "device": "LIGHT", "status": "SUCCESS", "action": "ON" }
      const key = `${resp.device}_${resp.action}`
      
      console.log(`⚡ [ACK] Nhận phản hồi từ ESP: ${resp.device} -> ${resp.action} (${resp.status})`)

      // Lấy người thực hiện từ lệnh gửi lúc trước (nếu có)
      let user = 'hoquangminh'
      if (pendingCommands.has(key)) {
        const cmd = pendingCommands.get(key)
        user = cmd.triggeredBy || 'hoquangminh'
        clearTimeout(cmd.timer)
        pendingCommands.delete(key)
        cmd.resolve({ success: true, data: resp })
      }

      deviceHistory.unshift({
        id: deviceIdCounter++,
        device: deviceNameMap[resp.device] || resp.device,
        action: resp.action,
        status: resp.status || 'SUCCESS',
        triggeredBy: user,
        time: formatDateTime(),
      })
    } catch (e) {
      console.error('[MQTT] Lỗi parse JSON từ device_response:', e.message)
    }
  }
})

// ─── 4. CÁC API RESTful CUNG CẤP CHO FRONTEND ─────────────────────────

// 4.1 Đăng nhập
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body
  if (username === 'hoquangminh' && password === '123') {
    return res.json({
      success: true,
      user: {
        username: 'hoquangminh',
        fullName: 'Hồ Quang Minh',
        role: 'ADMIN',
      },
    })
  }
  return res.status(401).json({ success: false, message: 'Sai tài khoản hoặc mật khẩu!' })
})

// 4.2 Lấy thông số cảm biến mới nhất (Dashboard gọi 3s/lần)
app.get('/api/sensors/latest', (req, res) => {
  // ESP phát số liệu 2s/lần, nếu quá 6 giây không thấy tin nhắn mới -> Phần cứng đã ngắt kết nối
  const isHardwareOnline = Date.now() - lastHardwareHeartbeat < 6000

  res.json({
    success: true,
    data: {
      ...latestSensor,
      chartData: recentChartPoints,
      isHardwareOnline,
    },
  })
})

// 4.3 Lấy danh sách lịch sử cảm biến (Trang Lịch sử cảm biến)
app.get('/api/sensors/history', (req, res) => {
  res.json({
    success: true,
    data: sensorHistory,
  })
})

// 4.4 Lấy danh sách lịch sử bật tắt thiết bị (Trang Lịch sử bật tắt)
app.get('/api/devices/history', (req, res) => {
  res.json({
    success: true,
    data: deviceHistory,
  })
})

// 4.5 Gửi lệnh điều khiển thiết bị (Dashboard gọi khi gạt công tắc)
app.post('/api/devices/control', (req, res) => {
  const { device, action, triggeredBy } = req.body // device: "LIGHT" | "FAN" | "AC", action: "ON" | "OFF"
  const user = triggeredBy || 'hoquangminh'

  if (!device || !action) {
    return res.status(400).json({ success: false, message: 'Thiếu device hoặc action!' })
  }

  const payload = JSON.stringify({ device, action })
  const key = `${device}_${action}`

  console.log(`🚀 [Control] Người dùng [${user}] yêu cầu: ${device} -> ${action}`)

  // Nếu MQTT Broker đang kết nối: gửi MQTT thật xuống mạch
  if (mqttClient.connected) {
    mqttClient.publish(TOPIC_CONTROL, payload, { qos: 1 }, (err) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Không thể publish tới MQTT Broker!' })
      }

      // Chờ ACK từ ESP8266 với timeout tối đa 4.5 giây
      const timer = setTimeout(() => {
        if (pendingCommands.has(key)) {
          pendingCommands.delete(key)
          
          const deviceNameMap = { LIGHT: 'Đèn', FAN: 'Quạt', AC: 'Điều hòa' }
          deviceHistory.unshift({
            id: deviceIdCounter++,
            device: deviceNameMap[device] || device,
            action: action,
            status: 'TIMEOUT',
            triggeredBy: user,
            time: formatDateTime(),
          })

          console.warn(`⏰ [Timeout] Thiết bị ${device} không phản hồi ACK sau 4.5s`)
          res.status(504).json({ success: false, message: 'Quá thời gian chờ phản hồi từ thiết bị (Timeout 5s)!' })
        }
      }, 4500)

      pendingCommands.set(key, {
        triggeredBy: user,
        resolve: (result) => {
          res.json({ success: true, message: `Thực hiện ${action} ${device} thành công!`, data: result.data })
        },
        timer,
      })
    })
  } else {
    // NẾU CHƯA CẮM PHẦN CỨNG / CHƯA BẬT BROKER: Tự động phản hồi thành công sau 150ms để test Postman và chụp ảnh!
    const deviceNameMap = { LIGHT: 'Đèn', FAN: 'Quạt', AC: 'Điều hòa' }
    deviceHistory.unshift({
      id: deviceIdCounter++,
      device: deviceNameMap[device] || device,
      action: action,
      status: 'SUCCESS',
      triggeredBy: user,
      time: formatDateTime(),
    })

    setTimeout(() => {
      res.json({
        success: true,
        message: `Thực hiện ${action} ${device} thành công! (Mô phỏng ACK)`,
        data: {
          device: device,
          status: 'SUCCESS',
          action: action,
        },
      })
    }, 150)
  }
})

// ─── 4.6 TÍCH HỢP SWAGGER API DOCS ────────────────────────────────────
const swaggerDocument = {
  openapi: '3.0.0',
  info: {
    title: 'Hệ Thống IoT Smart Home API',
    version: '1.0.0',
    description: 'Tài liệu API chính thức phục vụ hệ thống giám sát cảm biến và điều khiển thiết bị qua MQTT - Sinh viên: Hồ Quang Minh (B23DCAT191)',
  },
  servers: [
    {
      url: 'http://localhost:5000',
      description: 'Local Development Server',
    },
  ],
  paths: {
    '/api/auth/login': {
      post: {
        summary: 'Đăng nhập tài khoản hệ thống',
        description: 'Xác thực tài khoản người dùng để cấp quyền truy cập Dashboard',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  username: { type: 'string', example: 'hoquangminh' },
                  password: { type: 'string', example: '123' },
                },
              },
            },
          },
        },
        responses: {
          200: { description: 'Đăng nhập thành công' },
          401: { description: 'Sai tài khoản hoặc mật khẩu' },
        },
      },
    },
    '/api/sensors/latest': {
      get: {
        summary: 'Lấy dữ liệu cảm biến mới nhất & trạng thái mạch',
        description: 'Trả về nhiệt độ, độ ẩm, ánh sáng và kiểm tra nhịp tim ESP8266 (isHardwareOnline)',
        responses: {
          200: {
            description: 'Dữ liệu cảm biến thời gian thực',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    success: { type: 'boolean', example: true },
                    data: {
                      type: 'object',
                      properties: {
                        temperature: { type: 'number', example: 31.8 },
                        humidity: { type: 'number', example: 62.0 },
                        light_lux: { type: 'number', example: 450 },
                        time: { type: 'string', example: '20/10/2026 10:48' },
                        isHardwareOnline: { type: 'boolean', example: true },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    '/api/sensors/history': {
      get: {
        summary: 'Lấy lịch sử dữ liệu cảm biến',
        description: 'Trả về danh sách dữ liệu đo đạc cảm biến lưu trong bộ nhớ máy chủ',
        responses: {
          200: { description: 'Danh sách lịch sử cảm biến' },
        },
      },
    },
    '/api/devices/control': {
      post: {
        summary: 'Điều khiển Bật/Tắt thiết bị (Có bảo vệ ACK Timeout 5s)',
        description: 'Phát lệnh MQTT xuống mạch ESP8266, kiểm soát người thực hiện và chờ phản hồi',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['device', 'action'],
                properties: {
                  device: { type: 'string', enum: ['LIGHT', 'FAN', 'AC'], example: 'LIGHT' },
                  action: { type: 'string', enum: ['ON', 'OFF'], example: 'ON' },
                  triggeredBy: { type: 'string', example: 'hoquangminh' },
                },
              },
            },
          },
        },
        responses: {
          200: { description: 'Thực hiện lệnh thành công (Đã nhận ACK)' },
          504: { description: 'Quá thời gian chờ phản hồi từ phần cứng (Timeout 5s)' },
        },
      },
    },
    '/api/devices/history': {
      get: {
        summary: 'Lấy nhật ký lịch sử Bật/Tắt thiết bị',
        description: 'Truy vấn danh sách các lượt điều khiển thiết bị có ghi nhận vết người dùng',
        responses: {
          200: { description: 'Danh sách nhật ký điều khiển thiết bị' },
        },
      },
    },
  },
}

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument))

// ─── 5. KHỞI CHẠY SERVER ──────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n======================================================`)
  console.log(`🚀 IoT Backend Server đang chạy tại: http://localhost:${PORT}`)
  console.log(`📑 Swagger API Docs sẵn sàng tại: http://localhost:${PORT}/api-docs`)
  console.log(`📡 Đang kết nối MQTT: ${MQTT_BROKER_URL}`)
  console.log(`======================================================\n`)
})
